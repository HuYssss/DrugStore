package gr2.clc.drugstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
