package gr2.clc.drugstore.dto;

import lombok.*;

@Data
public class authLoginDTO {
    private String username;
    private String password;
}
